package net.minecraft.client;

import Client.Events.Event;

public class ClientTickEvent extends Event {}
